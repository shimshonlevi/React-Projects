export interface UserDto {
    username: string;
    password: string;
}